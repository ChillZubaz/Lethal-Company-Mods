## v3.0.0
- Fixed the Face to better show up in game