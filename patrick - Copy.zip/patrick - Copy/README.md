# Patrick Bateman Suit Mod 
Based on [Patrick Bateman Suit Mod - Thunderstore](https://thunderstore.io/c/lethal-company/p/ntous/Patrick_Bateman_Suit_Mod/) by [ntous](https://thunderstore.io/c/lethal-company/p/ntous/)  

## Purpose
Fixed The Face

## Making your own More Suits mod
To learn more about adding your own suits, go to [MoreSuits Mod -
Thunderstore](https://thunderstore.io/c/lethal-company/p/x753/More_Suits/)

## Source
Github Repo: [LCPatrickBatemanSuit](https://github.com/Wojtek-ftw/LCPatrickBatemanSuit)